/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad5;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD5 {

    public static void main(String[] args) {
        // Crear un arreglo multidimensional para almacenar datos personales
        String[][] datos = {
            {"Monica", "Jiz", "Computacion", "IMSA"},
            {"Ana", "Lopez", "Civil", "CONCONCRETO"},
            {"Luis", "Garcia", "Industrial", "GILDAN"},
            {"Daniel", "Medina", "Electronica", "TEST"},
            {"Carlos", "Perez", "Mecanica", "GM"},
        };

        // Imprimir los datos personales
        System.out.println("Datos personales de mis compañeros de clase:");
        for (int i = 0; i < datos.length; i++) {
            System.out.println("Nombre: " + datos[i][0]);
            System.out.println("Apellido: " + datos[i][1]);
            System.out.println("Carrera: " + datos[i][2]);
            System.out.println("Lugar de Trabajo: " + datos[i][3]);
            System.out.println();
        }
    }
    
}

