/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad1;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD1 {

    public static void main(String[] args) {
        System.out.println("Hola, Soy Maycol Aguilar");
    }
}
