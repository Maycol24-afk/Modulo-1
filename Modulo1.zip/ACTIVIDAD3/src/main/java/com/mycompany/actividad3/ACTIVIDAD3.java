/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad3;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD3 {

    public static void main(String[] args) {
       // Declarar y asignar valores a las variables
        int M = 6;
        int T = 1;
        int K = -10;

        // Evaluar las expresiones
        boolean Valor1 = M > T;
        boolean Valor2 = T / K == -5;
        boolean Valor3 = (M + T == 7) || (M - T == 5);

        // Imprimir los resultados
        System.out.println("Evaluar las expresiones:");
        System.out.println("M > T: " + Valor1);
        System.out.println("T / K == -5: " + Valor2);
        System.out.println("(M + T == 7) || (M - T == 5): " + Valor3);
    }
    
}

    

