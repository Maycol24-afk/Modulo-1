/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad4;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD4 {

    public static void main(String[] args) {
       
        String[] nombres = new String[10];

        // se Asignan nombres al arreglo
        nombres[0] = "Maycol";
        nombres[1] = "Dulce";
        nombres[2] = "Paola";
        nombres[3] = "Yovany";
        nombres[4] = "Barbarita";
        nombres[5] = "kevin";
        nombres[6] = "Wesly";
        nombres[7] = "Dayana";
        nombres[8] = "Rosa";
        nombres[9] = "Angel";

        // Imprimir los nombres
        System.out.println("Nombres de mis compañeros de clase:");
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
    
}

