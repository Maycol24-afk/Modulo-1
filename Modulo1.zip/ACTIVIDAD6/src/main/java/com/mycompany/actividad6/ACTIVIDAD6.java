/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad6;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD6 {

    public static void main(String[] args) {
       String[] Nombres = {"Dulce", "Kenia", "Julissa", "Juan", "Donovan"};
        int[] Notas = {65, 89, 74, 50, 92};

        // Evaluar y imprimir si aprobaron o reprobaron
        for (int i = 0; i < Nombres.length; i++) {
            String resultado = (Notas[i] >= 70) ? "Aprobado" : "Reprobado";
            System.out.println(Nombres[i]);
            System.out.println(Notas[i]);
            System.out.println(resultado);
            System.out.println();
        }
    }
    
}