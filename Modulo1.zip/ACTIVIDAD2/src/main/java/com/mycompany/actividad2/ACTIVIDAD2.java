/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.actividad2;

import java.util.Scanner;

/**
 *
 * @author DELL GAMING
 */
public class ACTIVIDAD2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario que ingrese dos Valores enteros.
        System.out.print("Ingrese el primer Valor entero: ");
        int Valor1 = scanner.nextInt();
        
        System.out.print("Ingrese el segundo número entero: ");
        int Valor2 = scanner.nextInt();

        // Realizar las operaciones aritméticas.
        int suma = Valor1 + Valor2;
        int resta = Valor1 - Valor2;
        int multiplicacion = Valor1 * Valor2;
        int division = Valor1 / Valor2;
        int modulo = Valor1 % Valor2;

        // Imprimir los resultados.
        System.out.println("Suma: " + Valor1 + " + " + Valor2 + " = " + suma);
        System.out.println("Resta: " + Valor1 + " - " + Valor2 + " = " + resta);
        System.out.println("Multiplicación: " + Valor1 + " * " + Valor2 + " = " + multiplicacion);
        System.out.println("División: " + Valor1 + " / " + Valor2 + " = " + division);
        System.out.println("Módulo: " + Valor1 + " % " + Valor2 + " = " + modulo);

        scanner.close();
    }
    
}
    

